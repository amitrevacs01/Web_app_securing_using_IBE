/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package network;

import Dbcon.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.Time;
import java.util.StringTokenizer;

/**
 *
 * @author Amit
 */
public class Req extends HttpServlet {

 
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
       try {
             String fid=request.getParameter("fid");
             String fname=request.getParameter("fname");
             String sk=request.getParameter("sk");
             String ownname=request.getParameter("owner_name");
             //System.out.println("fileiddddddddd ========"+fileid);
            
             
           HttpSession session = request.getSession(true);
                 Connection conn= DbConnection.getConnection();
               Statement st3=conn.createStatement();
                   ResultSet rs1=null; 
                   String uname=session.getAttribute("ssuname").toString();
                   System.out.println("ssname======="+uname);
                     //String  patient_name=(String)session.getAttribute("session_patient_name");
                     //System.out.println("pnameeee=========="+patient_name);
        
      //get current date time with Date()
             DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	     Date date = new Date();
             String Sdate= dateFormat.format(date); 
            rs1=st3.executeQuery("select * from  timeseal where fid='"+fid+"'and uname='"+uname+"'");
             if(rs1.next())
             {
                 
               String start=rs1.getString("start_time");
                 String End_date=rs1.getString("end_time");
                 Date sdate1=new Date(start);
                 Date edate=new Date(End_date);
                 String sdate2=dateFormat.format(sdate1);
                 String edate1=dateFormat.format(edate);
                 System.out.println("edate111111111"+edate1);
                         
//                String  End_date=(String)session.getAttribute("SSend_time");
//                System.out.println("system end date issssssssssss"+End_date);
               // Date edate=dateFormat.format(End_date);
//                String Edate=dateFormat.format(End_date);
                System.out.println("sdate from request.javvvvv"+Sdate);
 System.out.println("\n ewdate from request.javvvvv"+End_date);
               System.out.println("current Closing Date------>?>>>>>>>>>"+Sdate+ownname+End_date);
//                if(Sdate.compareTo(edate1)<0)
                   if(((Sdate.compareTo(sdate2)==0)||Sdate.compareTo(sdate2)>0) &&((Sdate.compareTo(edate1)==0)||Sdate.compareTo(edate1)<0))
                {
             
                                                
                  String  User_Name=(String)session.getAttribute("ssuname");
                  System.out.println("UserNAme----"+User_Name);
                   String  Email=(String)session.getAttribute("ssmail");
//                    String  State=(String)session.getAttribute("ssstate");
//                     String  Country=(String)session.getAttribute("sscountry");
                     //String  file_Name=(String)session.getAttribute("SSpatient");
                    //String  Secret_Key=(String)session.getAttribute("SSsecret_key"); 
                   String  Status="No";  
//       System.out.println("Request is activated"+Email+State+Country+file_Name+Secret_Key+Status);
	  	  
	 
       Connection con= DbConnection.getConnection();
        Statement st=con.createStatement();
		
        
            String sql="insert into request(user_name, email,file_name, secret_key, status) values ('"+User_Name+"','"+Email+"','"+fname+"','"+sk+"','"+Status+"')";
		
        int x=st.executeUpdate(sql);
		if(x!=0){
		response.sendRedirect("search_patient.jsp?msg=Request_send_Successfully");
	
		}
				else{
		response.sendRedirect("search_patient.jsp?message=fail");
		
		}
             }else{
                response.sendRedirect("search_patient.jsp?msggg='yes'");
            }
        }
             else
             {
                 response.sendRedirect("search_patient.jsp?ms2=u dont access permission");
             }
       }                   
        catch(Exception e)
                {
        e.printStackTrace();
		
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
