/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package network;
import Dbcon.DbConnection;
import algorithm.Decryption;
import algorithm.Ftpcon;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Amit
 */
public class edow extends HttpServlet {
String dn=null;
     String strLine="";
     String amit="";
      String da="";
      String skey="";
         String fname="";
         String content="";
         int fid;
         
    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      
        response.setContentType("text/html;charset=UTF-8");
        SimpleFTPClient client = null;
        HttpSession ses=request.getSession(true);
        PrintWriter out=response.getWriter();
        try {
           // String val = request.getParameter("keys");
             String file = ses.getAttribute("fname").toString();
            if(file==""){
            response.sendRedirect("emergency.jsp?msg=Invalid Request");
            }
            System.out.println("filename------iddddd--"+request.getParameter("keys"));
            Connection con = DbConnection.getConnection();
            PreparedStatement pstm = null;
            PreparedStatement pstm1 = null;
            PreparedStatement pstm2 = null;
            Statement st=con.createStatement();
//            String  fid=Integer.parseInt(request.getParameter("keys"));
//            System.out.println("fiddddd"+fid);
            String fname=ses.getAttribute("fname").toString();
            String sql = "select * from upload2 where filename='" + fname+"'";
            pstm = con.prepareStatement(sql);
           
            
            ResultSet rs = pstm.executeQuery();
           if (rs.next()) 
           {
               fname=rs.getString("filename");
               System.out.println("fname========="+fname);
               fid=rs.getInt("id");
               skey=rs.getString(7);
           
           PreparedStatement pssan=con.prepareStatement("select * from emdownlog where  fname='"+fname+"'");
           ResultSet rses=pssan.executeQuery();
           if(rses.next())
           {
              da=rses.getString("dwtime");
           }
            
            String currDate = new SimpleDateFormat("MM/dd/yyyy").format(new Date());
            if(da.equals(currDate))
            {
               response.sendRedirect("emergency.jsp?msges=Downloading Error"); 
            }
            else
            {
            PreparedStatement pses=con.prepareStatement("insert into emdownlog values(?,?,?)");
            pses.setInt(1, fid);
            pses.setString(2,fname);
            pses.setString(3, currDate);
            int ex=pses.executeUpdate();
//              
//               
            boolean status=new Ftpcon().filedownload(file);
              if(status)
              {
           System.out.println("fname-----------"+fname);
         
        
             
               System.out.println("skey is====="+skey);
           String s2=(rs.getString("content").toString());
           String owner=rs.getString("owner_name");
           System.out.println("s2222===="+s2);
                    String content= Decryption.decrypt(s2,skey);
         System.out.println("content============"+content);
         
         response.setHeader("Content-Disposition","attachment;filename=\""+fname+"\"");        
         out.write(content);
         out.flush();
         out.close();
      String sql1 = "DELETE FROM erequest WHERE fname='"+fname+"'";
pstm1 = con.prepareStatement(sql1);
int i = pstm1.executeUpdate();
         if(i>0)
         {
             response.sendRedirect("edow.jsp?msg=done");
            }
         else
         {
              response.sendRedirect("emergency.jsp?msges=Downloading Error"); 
         }
           }
            }
        }
        }
        
        
             catch (Exception e) {
                 response.sendRedirect("emergency.jsp?msg=Downloading Error");
            e.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
