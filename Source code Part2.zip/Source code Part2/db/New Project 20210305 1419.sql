-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.19


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema ibefile
--

CREATE DATABASE IF NOT EXISTS ibefile;
USE ibefile;

--
-- Definition of table `cache`
--

DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache` (
  `FileName` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cache`
--

/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;


--
-- Definition of table `downloads`
--

DROP TABLE IF EXISTS `downloads`;
CREATE TABLE `downloads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `time` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `downloads`
--

/*!40000 ALTER TABLE `downloads` DISABLE KEYS */;
INSERT INTO `downloads` (`id`,`filename`,`username`,`time`) VALUES 
 (1,'abc.txt','Amit','2019/05/02 02:27:16'),
 (2,'Amit.txt','Amith','2021/03/05 14:16:28');
/*!40000 ALTER TABLE `downloads` ENABLE KEYS */;


--
-- Definition of table `emdownlog`
--

DROP TABLE IF EXISTS `emdownlog`;
CREATE TABLE `emdownlog` (
  `fid` int(11) DEFAULT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `dwtime` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emdownlog`
--

/*!40000 ALTER TABLE `emdownlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `emdownlog` ENABLE KEYS */;


--
-- Definition of table `emergncey`
--

DROP TABLE IF EXISTS `emergncey`;
CREATE TABLE `emergncey` (
  `email` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emergncey`
--

/*!40000 ALTER TABLE `emergncey` DISABLE KEYS */;
/*!40000 ALTER TABLE `emergncey` ENABLE KEYS */;


--
-- Definition of table `erequest`
--

DROP TABLE IF EXISTS `erequest`;
CREATE TABLE `erequest` (
  `email` varchar(300) DEFAULT NULL,
  `fname` varchar(300) DEFAULT NULL,
  `pname` varchar(300) DEFAULT NULL,
  `secret_key` varchar(300) DEFAULT NULL,
  `status` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `erequest`
--

/*!40000 ALTER TABLE `erequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `erequest` ENABLE KEYS */;


--
-- Definition of table `reg`
--

DROP TABLE IF EXISTS `reg`;
CREATE TABLE `reg` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `uname` varchar(45) NOT NULL,
  `pass` varchar(45) NOT NULL,
  `dob` varchar(45) NOT NULL,
  `state` varchar(45) NOT NULL,
  `country` varchar(45) NOT NULL,
  `role` varchar(45) NOT NULL,
  `permission` varchar(45) NOT NULL,
  `secret_key` varchar(45) DEFAULT NULL,
  `temail` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg`
--

/*!40000 ALTER TABLE `reg` DISABLE KEYS */;
INSERT INTO `reg` (`id`,`fname`,`lname`,`email`,`uname`,`pass`,`dob`,`state`,`country`,`role`,`permission`,`secret_key`,`temail`) VALUES 
 (2,'Amit','k','amitbiz28@gmail.com','Amit','Amit@001','1988-07-02','Karnataka','India','Owner','Allowed','13385','amitlambi@gmail.com'),
 (3,'Amith','k','amitlambi@gmail.com','Amit','Amit@01','1970-08-24','Karnataka','India','insurance','Allowed','76049',NULL);
/*!40000 ALTER TABLE `reg` ENABLE KEYS */;


--
-- Definition of table `request`
--

DROP TABLE IF EXISTS `request`;
CREATE TABLE `request` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `file_name` varchar(45) NOT NULL,
  `secret_key` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `request`
--

/*!40000 ALTER TABLE `request` DISABLE KEYS */;
INSERT INTO `request` (`id`,`user_name`,`email`,`file_name`,`secret_key`,`status`) VALUES 
 (1,'Amith','amitlambi@gmail.com','Amit.txt','Pv2h6dWHlVuof9qb6Bzyrw==','Yes');
/*!40000 ALTER TABLE `request` ENABLE KEYS */;


--
-- Definition of table `takecare`
--

DROP TABLE IF EXISTS `takecare`;
CREATE TABLE `takecare` (
  `temail` varchar(300) DEFAULT NULL,
  `pname` varchar(300) DEFAULT NULL,
  `otp` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `takecare`
--

/*!40000 ALTER TABLE `takecare` DISABLE KEYS */;
INSERT INTO `takecare` (`temail`,`pname`,`otp`) VALUES 
 ('amitbiz28@gmail.com','Amit','null');
/*!40000 ALTER TABLE `takecare` ENABLE KEYS */;


--
-- Definition of table `timeseal`
--

DROP TABLE IF EXISTS `timeseal`;
CREATE TABLE `timeseal` (
  `fid` int(11) DEFAULT NULL,
  `uname` varchar(300) DEFAULT NULL,
  `start_time` varchar(300) DEFAULT NULL,
  `end_time` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timeseal`
--

/*!40000 ALTER TABLE `timeseal` DISABLE KEYS */;
INSERT INTO `timeseal` (`fid`,`uname`,`start_time`,`end_time`) VALUES 
 (2,'Amith','5-Mar-2021 14:10:56','31-Mar-2021 14:10:56');
/*!40000 ALTER TABLE `timeseal` ENABLE KEYS */;


--
-- Definition of table `upload`
--

DROP TABLE IF EXISTS `upload`;
CREATE TABLE `upload` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(45) NOT NULL,
  `content` longblob NOT NULL,
  `owner_name` varchar(45) NOT NULL,
  `start_time` varchar(45) NOT NULL,
  `end_time` varchar(45) NOT NULL,
  `secret_key` varchar(45) NOT NULL,
  `patient` varchar(45) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `keyword` varchar(50) DEFAULT NULL,
  `cat` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload`
--

/*!40000 ALTER TABLE `upload` DISABLE KEYS */;
/*!40000 ALTER TABLE `upload` ENABLE KEYS */;


--
-- Definition of table `upload2`
--

DROP TABLE IF EXISTS `upload2`;
CREATE TABLE `upload2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(50) DEFAULT NULL,
  `content` longblob,
  `owner_name` varchar(50) DEFAULT NULL,
  `start_time` varchar(50) DEFAULT NULL,
  `end_time` varchar(50) DEFAULT NULL,
  `sceret_key` varchar(50) DEFAULT NULL,
  `patient` varchar(50) DEFAULT NULL,
  `docdep` varchar(1024) DEFAULT NULL,
  `perinfo` varchar(1024) DEFAULT NULL,
  `comoinfo` varchar(1024) DEFAULT NULL,
  `masterkey` varchar(255) DEFAULT NULL,
  `publickey` varchar(255) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `keyword` varchar(1024) DEFAULT NULL,
  `cat` varchar(300) DEFAULT NULL,
  `rank_` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload2`
--

/*!40000 ALTER TABLE `upload2` DISABLE KEYS */;
/*!40000 ALTER TABLE `upload2` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
